*****************Welecome to a simple TikTacToe Game*****************

I)Simply run the TikTacToe.jar file.
II)Two players can play this game.
III)To restart the game simply close the application and open it again.
